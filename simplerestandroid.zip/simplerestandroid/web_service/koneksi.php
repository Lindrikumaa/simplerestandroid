<?php
 define('HOST','localhost');
 define('USER','id12804500_lindri');
 define('PASS','12345');
 define('DB','id12804500_penjualan');

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');